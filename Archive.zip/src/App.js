import Admin from "./components/Admin";

function App() {
  return (
    <div>
      <Admin />
    </div>
  );
}

export default App;
